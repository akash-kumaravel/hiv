import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { RunwareService, GeneratedImage } from "@/lib/runware";
import { Loader2, Download, Sparkles, Wand2 } from "lucide-react";
import gsap from "gsap";

interface ImageGeneratorProps {
  apiKey: string;
}

export function ImageGenerator({ apiKey }: ImageGeneratorProps) {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([]);
  const [runwareService, setRunwareService] = useState<RunwareService | null>(null);
  
  const formRef = useRef<HTMLDivElement>(null);
  const galleryRef = useRef<HTMLDivElement>(null);
  const loadingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (apiKey) {
      setRunwareService(new RunwareService(apiKey));
    }
  }, [apiKey]);

  useEffect(() => {
    // Animate form entrance
    if (formRef.current) {
      gsap.fromTo(formRef.current, 
        { opacity: 0, y: 50 },
        { opacity: 1, y: 0, duration: 1, ease: "power3.out", delay: 0.3 }
      );
    }
  }, []);

  const generateImage = async () => {
    if (!prompt.trim() || !runwareService) {
      toast.error("Please enter a prompt and ensure API key is set");
      return;
    }

    setIsGenerating(true);
    
    // Animate loading state
    if (loadingRef.current) {
      gsap.fromTo(loadingRef.current,
        { opacity: 0, scale: 0.8 },
        { opacity: 1, scale: 1, duration: 0.5, ease: "back.out(1.7)" }
      );
    }

    try {
      const result = await runwareService.generateImage({
        positivePrompt: prompt,
        width: 1024,
        height: 1024,
        numberResults: 1
      });

      setGeneratedImages(prev => [result, ...prev]);
      
      // Animate new image
      setTimeout(() => {
        const newImageCard = galleryRef.current?.firstElementChild;
        if (newImageCard) {
          gsap.fromTo(newImageCard,
            { opacity: 0, scale: 0.8, rotateY: 90 },
            { opacity: 1, scale: 1, rotateY: 0, duration: 0.8, ease: "back.out(1.7)" }
          );
        }
      }, 100);

      toast.success("Image generated successfully!");
    } catch (error) {
      console.error("Generation error:", error);
      toast.error("Failed to generate image. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadImage = async (imageUrl: string, prompt: string) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `generated-${prompt.slice(0, 20).replace(/[^a-zA-Z0-9]/g, '-')}.webp`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success("Image downloaded!");
    } catch (error) {
      toast.error("Failed to download image");
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8">
      {/* Generation Form */}
      <div ref={formRef} className="mb-12">
        <Card className="glass p-8 glow-border">
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold glow-text mb-2">Create Amazing Images</h2>
              <p className="text-muted-foreground">Describe your vision and watch it come to life</p>
            </div>
            
            <div className="space-y-4">
              <Textarea
                placeholder="Describe the image you want to create... (e.g., 'A mystical forest with glowing mushrooms at twilight')"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-[120px] glass border-cosmic-purple/30 focus:border-cosmic-purple/60 text-lg resize-none"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                    generateImage();
                  }
                }}
              />
              
              <div className="flex justify-center">
                <Button
                  onClick={generateImage}
                  disabled={isGenerating || !prompt.trim()}
                  className="btn-cosmic px-8 py-6 text-lg font-semibold group"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Creating Magic...
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
                      Generate Image
                      <Sparkles className="w-4 h-4 ml-2 group-hover:scale-110 transition-transform" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Loading State */}
      {isGenerating && (
        <div ref={loadingRef} className="text-center mb-8">
          <div className="inline-flex items-center space-x-2 text-cosmic-purple animate-pulse-glow">
            <Sparkles className="w-6 h-6 animate-spin" />
            <span className="text-xl font-medium">Generating your masterpiece...</span>
            <Sparkles className="w-6 h-6 animate-spin" />
          </div>
        </div>
      )}

      {/* Image Gallery */}
      {generatedImages.length > 0 && (
        <div ref={galleryRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {generatedImages.map((image, index) => (
            <Card key={image.imageUUID} className="glass overflow-hidden group hover:scale-105 transition-transform duration-300">
              <div className="aspect-square relative overflow-hidden">
                <img
                  src={image.imageURL}
                  alt={image.positivePrompt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Download Button */}
                <Button
                  onClick={() => downloadImage(image.imageURL, image.positivePrompt)}
                  className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/50 hover:bg-black/70 backdrop-blur-sm border-0"
                  size="icon"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="p-4">
                <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                  {image.positivePrompt}
                </p>
                <div className="flex justify-between items-center text-xs text-muted-foreground">
                  <span>Seed: {image.seed}</span>
                  <span className={image.NSFWContent ? "text-red-400" : "text-green-400"}>
                    {image.NSFWContent ? "NSFW" : "Safe"}
                  </span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {generatedImages.length === 0 && !isGenerating && (
        <div className="text-center py-16">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-cosmic animate-pulse-glow flex items-center justify-center">
            <Sparkles className="w-16 h-16 text-white animate-float" />
          </div>
          <h3 className="text-2xl font-semibold mb-2 glow-text">Ready to Create</h3>
          <p className="text-muted-foreground">Enter a prompt above to generate your first image</p>
        </div>
      )}
    </div>
  );
}