import { useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Sparkles, Wand2, Zap } from "lucide-react";
import gsap from "gsap";

interface HeroProps {
  onGetStarted: () => void;
}

export function Hero({ onGetStarted }: HeroProps) {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const particlesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline();

    // Animate hero elements
    tl.fromTo(titleRef.current,
      { opacity: 0, y: 100, scale: 0.8 },
      { opacity: 1, y: 0, scale: 1, duration: 1.2, ease: "back.out(1.7)" }
    )
    .fromTo(subtitleRef.current,
      { opacity: 0, y: 50 },
      { opacity: 1, y: 0, duration: 0.8, ease: "power3.out" },
      "-=0.8"
    )
    .fromTo(buttonRef.current,
      { opacity: 0, y: 30, scale: 0.9 },
      { opacity: 1, y: 0, scale: 1, duration: 0.6, ease: "back.out(1.7)" },
      "-=0.4"
    );

    // Create floating particles
    const createParticle = () => {
      const particle = document.createElement('div');
      particle.className = 'absolute w-2 h-2 bg-cosmic-purple rounded-full opacity-30';
      particlesRef.current?.appendChild(particle);

      gsap.set(particle, {
        x: Math.random() * window.innerWidth,
        y: window.innerHeight + 10
      });

      gsap.to(particle, {
        y: -10,
        x: `+=${Math.random() * 200 - 100}`,
        duration: Math.random() * 3 + 2,
        ease: "none",
        onComplete: () => particle.remove()
      });
    };

    const particleInterval = setInterval(createParticle, 300);

    return () => {
      clearInterval(particleInterval);
    };
  }, []);

  return (
    <div ref={heroRef} className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated Background Particles */}
      <div ref={particlesRef} className="absolute inset-0 pointer-events-none" />

      {/* Main Content */}
      <div className="text-center z-10 px-4">
        <h1 
          ref={titleRef}
          className="text-6xl md:text-8xl font-bold mb-6 glow-text bg-gradient-aurora bg-clip-text text-transparent"
        >
          Imagine
          <span className="block text-5xl md:text-7xl mt-2">Anything</span>
        </h1>
        
        <p 
          ref={subtitleRef}
          className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed"
        >
          Transform your ideas into stunning visuals with the power of AI. 
          Create, explore, and bring your imagination to life.
        </p>

        <Button
          ref={buttonRef}
          onClick={onGetStarted}
          className="btn-cosmic px-12 py-8 text-xl font-bold group relative overflow-hidden"
        >
          <Zap className="w-6 h-6 mr-3 group-hover:scale-110 transition-transform" />
          Start Creating
          <Sparkles className="w-5 h-5 ml-3 group-hover:rotate-12 transition-transform" />
          
          {/* Button glow effect */}
          <div className="absolute inset-0 bg-gradient-aurora opacity-0 group-hover:opacity-30 transition-opacity duration-300" />
        </Button>

        {/* Floating Icons */}
        <div className="absolute top-1/4 left-1/4 text-cosmic-purple/30 animate-float">
          <Wand2 size={32} />
        </div>
        <div className="absolute top-1/3 right-1/4 text-cosmic-blue/30 animate-float" style={{ animationDelay: '1s' }}>
          <Sparkles size={28} />
        </div>
        <div className="absolute bottom-1/3 left-1/3 text-cosmic-pink/30 animate-float" style={{ animationDelay: '2s' }}>
          <Zap size={24} />
        </div>
      </div>

      {/* Background Glow */}
      <div className="absolute inset-0 bg-gradient-cosmic opacity-10 animate-pulse-glow" />
    </div>
  );
}