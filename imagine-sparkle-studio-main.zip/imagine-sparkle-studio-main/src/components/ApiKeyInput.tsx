import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Key, ExternalLink, Sparkles } from "lucide-react";
import gsap from "gsap";

interface ApiKeyInputProps {
  onApiKeySubmit: (apiKey: string) => void;
}

export function ApiKeyInput({ onApiKeySubmit }: ApiKeyInputProps) {
  const [apiKey, setApiKey] = useState("");
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Animate card entrance
    if (cardRef.current) {
      gsap.fromTo(cardRef.current,
        { opacity: 0, y: 100, scale: 0.8 },
        { opacity: 1, y: 0, scale: 1, duration: 1.2, ease: "back.out(1.7)", delay: 0.5 }
      );
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (apiKey.trim()) {
      onApiKeySubmit(apiKey.trim());
      
      // Animate exit
      if (cardRef.current) {
        gsap.to(cardRef.current, {
          opacity: 0,
          scale: 0.8,
          y: -50,
          duration: 0.5,
          ease: "power2.in"
        });
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card ref={cardRef} className="glass p-8 w-full max-w-md glow-border">
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-cosmic flex items-center justify-center animate-pulse-glow">
            <Key className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold glow-text mb-2">Enter Your API Key</h1>
          <p className="text-muted-foreground">
            Enter your Runware API key to start generating images
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Input
              type="password"
              placeholder="Enter your Runware API key..."
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="glass border-cosmic-purple/30 focus:border-cosmic-purple/60 text-center"
            />
          </div>

          <Button
            type="submit"
            disabled={!apiKey.trim()}
            className="btn-cosmic w-full py-6 text-lg font-semibold group"
          >
            <Sparkles className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
            Start Creating
          </Button>
        </form>

        <div className="mt-6 pt-6 border-t border-cosmic-purple/20">
          <p className="text-sm text-muted-foreground text-center mb-4">
            Don't have an API key yet?
          </p>
          <Button
            variant="outline"
            className="w-full glass border-cosmic-purple/30 hover:border-cosmic-purple/60 group"
            onClick={() => window.open('https://runware.ai/', '_blank')}
          >
            <ExternalLink className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
            Get Your API Key
          </Button>
        </div>
      </Card>
    </div>
  );
}